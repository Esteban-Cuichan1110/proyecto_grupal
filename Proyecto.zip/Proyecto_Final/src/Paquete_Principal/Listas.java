/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Paquete_Principal;

import java.util.ArrayList;

/**
 *
 * @author Esteban
 */
public class Listas {
    ArrayList<Producto> inventario=new ArrayList<>();
}
