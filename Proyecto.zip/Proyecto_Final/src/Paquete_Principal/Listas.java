/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Paquete_Principal;

import java.util.ArrayList;

/**
 *
 * @author Esteban
 */
public class Listas {
    public static ArrayList<Laptop> laptops_ingresadas=new ArrayList<>();
    public static ArrayList<Telefono> telefonos_ingresados=new ArrayList<>();
    
    public void agregarLaptop(Laptop lapt){
        laptops_ingresadas.add(lapt);
    }
    
    public void agregartelefono(Telefono telf){
        telefonos_ingresados.add(telf);
    }
    
    public ArrayList<Laptop> getLaptop(){
        return laptops_ingresadas;
    }

    public ArrayList<Telefono> getTelefono(){
        return telefonos_ingresados;
    }
    
}
