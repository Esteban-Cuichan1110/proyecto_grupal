/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Paquete_Principal;

/**
 *
 * @author Esteban
 */
public class Administrador {
    public String usuario;
    public String clave;
    
    public boolean Autenticar(String usuario,String clave){
        if(usuario.equals("admin") && clave.equals("admin")){
            System.out.println("Bienvenido! Administrador");
            return true;
        }else{
           System.out.println("Ingreso incorrecto!");
           return false;
        }

    }
}
